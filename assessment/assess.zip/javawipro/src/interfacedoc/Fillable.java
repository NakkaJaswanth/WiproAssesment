package interfacedoc;

public interface Fillable {
	 void fillingColor();
	    void size();

}

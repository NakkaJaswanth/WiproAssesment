package interfacedoc;

public interface Drawable {
	    void drawingColor();
	    void thickness();
	}


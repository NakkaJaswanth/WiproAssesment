package javawipro;

public class array1 {

}

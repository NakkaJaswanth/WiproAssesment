package javawipro;

public class operations {
	public static void main(String[] args) {
	    int x = 5;
	    int y = 3;
	    System.out.println(x + y);
	    
	    System.out.println(x > y);
	    x += 5;
	    System.out.println(x);
	    String txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	    System.out.println("The length of the txt string is: " + txt.length());
	    String firstName = "John";
	    String lastName = "Doe";
	    System.out.println(firstName + " " + lastName);
	}
}

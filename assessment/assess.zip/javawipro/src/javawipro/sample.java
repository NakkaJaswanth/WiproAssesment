package javawipro;

public class sample {
	public static void main(String[] args) {
		byte amount = 50;
		short amount1 = 565;
		int salary = 565699;
		long score = 545456452222225L;
		System.out.println("Floating point:: "+amount+ " "+amount1+" "+salary+" "+score);
		float f1 = 35e3f;
	    double d1 = 12E4d;
	    System.out.println(f1);
	    System.out.println(d1);
	    boolean isJavaFun = true;
	    boolean isFishTasty = false;
	    System.out.println(isJavaFun);     
	    System.out.println(isFishTasty);
	    
		

}
}

package javawipro;

public class question2 {
	    public static void main(String[] args) {
	        int number = 2345;
	        number += 8; 
	        number /= 3; 
	        number %= 5; 
	        number *= 5; 
	        System.out.println("Final Result: " + number);
	    }
	}




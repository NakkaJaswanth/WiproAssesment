package javawipro;

public class question3 {
	    public static void main(String[] args) {
	        int totalStudents = 90;
	        int totalBoys = 45;

	       
	        int gradeAStudents = totalStudents / 2;

	        
	        int boysWithGradeA = 20;

	        
	        int girlsWithGradeA = gradeAStudents - boysWithGradeA;

	        
	        System.out.println("Total number of girls getting grade 'A': " + girlsWithGradeA);
	    }
	}



package javawipro;

public class question1 {
	    public static void main(String[] args) {
	        int number = 2345;
	        number += 8;
	        int quotient = number / 3;
	        int Result = quotient % 5;
	        int finalResult = Result * 5;
	        System.out.println("Final Result: " + finalResult);
	    }
	}




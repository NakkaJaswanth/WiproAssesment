package mymockito;

public interface calcservices 
	{
		   public int add(int input1, int input2);
		   public int subtract(int input1, int input2);
		   public int multiply(int input1, int input2);
		   public int divide(int input1, int input2);

	}



